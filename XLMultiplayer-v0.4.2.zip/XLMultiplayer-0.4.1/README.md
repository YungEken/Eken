# XLMultiplayer
Skater XL Multiplayer mod by silentbaws


# How to install
For instructions on installing the mod check the SkaterXL Discord https://discordapp.com/invite/mx2mE5h channel #all-tutorials and for any help ask in #help
